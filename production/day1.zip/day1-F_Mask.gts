G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-07-02T06:17:28-07:00*
G04 #@! TF.ProjectId,day1,64617931-2e6b-4696-9361-645f70636258,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-02 06:17:28*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
